﻿using System;
using System.Collections.Generic;
using Inventory;

namespace Inventory
{
    public class Albums
    {
        public string Genre { get; set; }

        public override string ToString()
        {
            return "Albums " + Genre;
        }
    }

    // Class for Rock album 
    public class HowItEnds : Albums
    {
        public string ArtistName { get; set; }

        public override string ToString()
        {
            return "HowItEnds" + ArtistName + Genre;
        }

    }

}

namespace CLKC2
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How many records do you want to add? ");
            var numberOfRecords = int.Parse(Console.ReadLine());

            var recordList = new List<HowItEnds>();

            for (int i = 0; i < numberOfRecords; i++)
            {
                var HowItEnds = new HowItEnds();
               
                // In this loop, populate the object's properties using Console.ReadLine()

                Console.WriteLine("Enter the Artist name");
                HowItEnds.ArtistName = Console.ReadLine();

                Console.WriteLine("What genre is this album?");
                HowItEnds.Genre = Console.ReadLine();

                recordList.Add(HowItEnds);
            }

           foreach(var HowItEnds in recordList)
            {
                Console.WriteLine("Artist Name: " + HowItEnds.ArtistName);
                Console.WriteLine("Genre: " + HowItEnds.Genre);
            }
        }
    }



}

